Integrantes:
- João Cristian Félix Proença
- Isabeli Martins Silva
- Letícia Nikole Gomes Benjamin
- Lucas Tomaz Chaves